-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 17, 2017 at 09:11 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ereservation`
--
CREATE DATABASE `ereservation` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ereservation`;

-- --------------------------------------------------------

--
-- Table structure for table `accommodation`
--

CREATE TABLE IF NOT EXISTS `accommodation` (
  `LocationID` varchar(100) NOT NULL,
  `LocationName` varchar(200) DEFAULT NULL,
  `LocationImage` varchar(200) DEFAULT NULL,
  `LocationDesc` tinytext,
  PRIMARY KEY (`LocationID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accommodation`
--

INSERT INTO `accommodation` (`LocationID`, `LocationName`, `LocationImage`, `LocationDesc`) VALUES
('L006', 'danang', 'danangVietnam.jpg', 'Notre hotel est situé a 4 km a la rentree de la ville'),
('L007', 'baclieu', 'baclieuVietnam.jpg', '\r\nSitue au cœur de la ville de Bac Lieu, province de Bac Lieu, CORINTHIA Hotel est une place villégiature ideale pour se detendre dans un environnement naturel en degustant des plats traditionnels du Sud.\r\n\r\nUn lieu romantique avec des secteurs de loisir '),
('L008', 'nhatrang', 'nhatrang.jpg', 'Corinthia Hotel a 5 km de la plage');

-- --------------------------------------------------------

--
-- Table structure for table `bookingsinfo`
--

CREATE TABLE IF NOT EXISTS `bookingsinfo` (
  `BookingID` varchar(100) NOT NULL,
  `ResortID` varchar(100) DEFAULT NULL,
  `RoomID` varchar(100) DEFAULT NULL,
  `LocationName` varchar(100) DEFAULT NULL,
  `UserID` varchar(100) DEFAULT NULL,
  `MemberType` varchar(100) DEFAULT NULL,
  `RoomCharges` float DEFAULT NULL,
  `From` date DEFAULT NULL,
  `To` date DEFAULT NULL,
  `BookingStatus` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`BookingID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookingsinfo`
--


-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `FId` int(10) NOT NULL AUTO_INCREMENT,
  `UserID` varchar(100) DEFAULT NULL,
  `Feedback` text,
  `DateSubmitted` date DEFAULT NULL,
  PRIMARY KEY (`FId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FId`, `UserID`, `Feedback`, `DateSubmitted`) VALUES
(2, 'eliodor', 'Bon hotel avec des employÃ©s gentils et experimentÃ©s', '2017-11-03'),
(3, 'eliodor', 'ca ete bon', '2017-11-09'),
(4, 'eliodor', 'Parfait', '2017-11-09'),
(5, 'Florial', 'Parfait', '2017-11-16'),
(6, 'Methode', 'bon souvenir', '2017-11-16');

-- --------------------------------------------------------

--
-- Table structure for table `invites`
--

CREATE TABLE IF NOT EXISTS `invites` (
  `Sno` int(10) NOT NULL AUTO_INCREMENT,
  `From` varchar(200) NOT NULL DEFAULT '',
  `To` varchar(200) DEFAULT NULL,
  `Status` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `invites`
--


-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `UserID` varchar(200) NOT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `Auth` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`UserID`, `Password`, `Auth`) VALUES
('admin', 'admin', '0'),
('Florial', 'ffff', '1'),
('Rebecca', 'rrrr', '1');

-- --------------------------------------------------------

--
-- Table structure for table `resortsinfo`
--

CREATE TABLE IF NOT EXISTS `resortsinfo` (
  `ResortID` varchar(100) NOT NULL,
  `LocationName` varchar(100) DEFAULT NULL,
  `ResortImage` varchar(200) DEFAULT NULL,
  `NoOfRooms` int(50) DEFAULT NULL,
  `NoOfRoomsAvailable` int(50) DEFAULT NULL,
  `Restaurant` varchar(100) DEFAULT NULL,
  `Swimmingpool` varchar(100) DEFAULT NULL,
  `GamesRoom` varchar(100) DEFAULT NULL,
  `Casino` varchar(100) DEFAULT NULL,
  `YogaandMeditation` varchar(100) DEFAULT NULL,
  `SteamBath` varchar(100) DEFAULT NULL,
  `GymandHealthCenter` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ResortID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resortsinfo`
--

INSERT INTO `resortsinfo` (`ResortID`, `LocationName`, `ResortImage`, `NoOfRooms`, `NoOfRoomsAvailable`, `Restaurant`, `Swimmingpool`, `GamesRoom`, `Casino`, `YogaandMeditation`, `SteamBath`, `GymandHealthCenter`) VALUES
('R007', 'Danang', 'corinthiadanang.jpg', 6, 6, 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes'),
('R008', 'baclieu', 'backlieuhotel.png', 10, 10, 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes'),
('R009', 'nhatrang', 'nhatranghotel.jpg', 13, 13, 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `roomsinfo`
--

CREATE TABLE IF NOT EXISTS `roomsinfo` (
  `Sno` varchar(100) NOT NULL,
  `RoomID` varchar(100) DEFAULT NULL,
  `ResortID` varchar(100) DEFAULT NULL,
  `LocationName` varchar(100) DEFAULT NULL,
  `RoomType` varchar(100) DEFAULT NULL,
  `RoomArea` varchar(100) DEFAULT NULL,
  `DryKitchenette` varchar(100) DEFAULT NULL,
  `SofacumBed` varchar(100) DEFAULT NULL,
  `DoubleBeds` varchar(100) DEFAULT NULL,
  `Telephone` varchar(100) DEFAULT NULL,
  `Television` varchar(100) DEFAULT NULL,
  `RoomCharges` float DEFAULT NULL,
  PRIMARY KEY (`Sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roomsinfo`
--

INSERT INTO `roomsinfo` (`Sno`, `RoomID`, `ResortID`, `LocationName`, `RoomType`, `RoomArea`, `DryKitchenette`, `SofacumBed`, `DoubleBeds`, `Telephone`, `Television`, `RoomCharges`) VALUES
('11', 'R00811', 'R008', 'baclieu', 'StudioApartment', '4', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 200),
('12', 'R00712', 'R007', 'Danang', 'StudioApartment', '12', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 500),
('13', 'R00913', 'R009', 'nhatrang', 'SingleBedRoomApartment', '5', 'Yes', 'No', 'No', 'Yes', 'No', 145),
('14', 'R00714', 'R007', 'Danang', 'DoubleBedRoomApartment', '30', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 600);

-- --------------------------------------------------------

--
-- Table structure for table `userprofile`
--

CREATE TABLE IF NOT EXISTS `userprofile` (
  `RegID` varchar(50) NOT NULL,
  `UserID` varchar(100) DEFAULT NULL,
  `FirstName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `Age` varchar(100) DEFAULT NULL,
  `EmailAddress` varchar(100) DEFAULT NULL,
  `Address` tinytext,
  `ContactNumber` varchar(100) DEFAULT NULL,
  `Occupation` varchar(100) DEFAULT NULL,
  `MemberType` varchar(100) DEFAULT NULL,
  `AmountDeposited` float DEFAULT NULL,
  `approve` int(1) DEFAULT NULL,
  PRIMARY KEY (`RegID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userprofile`
--

INSERT INTO `userprofile` (`RegID`, `UserID`, `FirstName`, `LastName`, `Age`, `EmailAddress`, `Address`, `ContactNumber`, `Occupation`, `MemberType`, `AmountDeposited`, `approve`) VALUES
('M001', 'Ram', 'Ram', 'Raju', '35', 'Ram@yahoo.com', 'Ram,KPHB,Hyderabad', '65545658', 'Business', 'Gold', 10000, 1),
('M0010', 'Guy', 'Guy', 'Mirlin', '30', 'guy@gmail.com', 'Hanoi, Vietnam', '+8477272722', 'Etudiant', '', 900, 1),
('M0011', 'Rebecca', 'Rebecca', 'Jacques Leblanc', '29', 'jleblanc@gmail.com', 'USA', '+5097678765', 'Commercant', 'Blocked', 970, 1),
('M0012', 'Florial', 'Florial', 'Jean Baptiste', '25', 'jbflorial2@gmail.com', 'Ky Tuc Xa, My Dinh', '+841653826678', 'Etudiant', 'Officiel', 9552, 1),
('M0013', 'methode', 'methode', 'niyonkuru', '36', 'methode.niyonkuru@gmail.com', 'Ky Tuc Xa My Dinh', '+8765454333', 'Etudiant', 'Etranger', 9809.6, 1),
('M0014', 'eritoine', 'Eritoine', 'Junior', '55', 'erioine.jacques@gmail.com', 'Port-au-Prince, Haiti, Rue Joseph', '+50934445676', 'Commercant', 'Etranger', 9809.6, 1),
('M002', 'Rajesh', 'Rajesh', '', '40', 'Raj@hotmail.com', 'Raj,Ameerpet,Hyderabad', '9842313211', 'Business', 'Platinum', 15000, 1),
('M003', 'kalyan', 'kalyan', '', '25', 'kalyan@gmail.com', 'kalyan,Banglore-21', '65524845', 'SE', 'Platinum', 15000, 1),
('M004', 'Rahul', 'Rahul', 'Roy', '25', 'Rahul@gmail.com', 'Hyderabad', '9989989989', 'Business', 'Gold', 10000, 1),
('M005', 'Subhas', 'Subhas', 'Ghai', '43', 'Subhas@yahoo.com', 'Hyderabad', '9989989989', 'Film Maker', 'Gold', 10000, 1),
('M006', 'eliodor', 'Ednalson Guy Mirlin', 'ELIODOR', '34', 'eliodor@gmail.com', 'Hanoi', '090909', 'Commercant', 'Silver', 1136.8, 1),
('M007', 'Perrault', 'Perrault', 'ANDRE', '26', 'andre.perrault@gmail.com', 'Hanoi, Vietnam', '09989878', 'etudiant', 'Silver', 799.6, 1),
('M008', 'Cephas', 'Cephas', 'Biakota', '24', 'cephas.biakota@gmail.com', 'Ky Tuc Xa My Dinh', '+842563457689', 'Etudiant', 'Silver', 1000, 1),
('M009', 'Cesar', 'Jean Rony', 'Cesar', '26', 'c.jeanrony@gmail.com', 'Allemagne', '+1345673849', 'Etudiant', 'Silver', 1000, 1);
